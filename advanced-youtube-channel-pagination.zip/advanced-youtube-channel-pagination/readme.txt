=== Advanced Youtube Channel Pagination ===
Plugin Name: Advanced Youtube Channel Pagination
Contributors: (https://profiles.wordpress.org/balasahebbhise)
Author: Mr. Balasaheb Bhise
Tags: Youtube, Youtube Channel Pagination, Youtube Videos Pagination, Youtube Channel, Youtube Videos, Pagination, Youtube Videos pagination, gallery,Advanced Youtube Channel Pagination, Youtube API 3.
Requires at least: 4.1
Tested up to: 4.6
Stable tag: 4.6
License: GPLv2 or later
License URI: https://github.com/balasahebbhise/advanced-youtube-channel-pagination
Description:The plugin is usefull for showing youtube channel videos with pagination.

Copyright 2016 Balasaheb Bhise  (email : balasahebbhise1@gmail.com)

== Description ==

The plugin is usefull for showing youtube channel videos with pagination.This plugin for list youtube channel video on your web site.
Website owner have to create Channel on youtube and get channel id and create api key form goole API. and set form admin side channel id, API key, and select how money video per setting form admin.

== Installation ==

Upload the Youtube Channel Pagination plugin to your plugin, Activate it, then use this short code on for page [Advanced_Youtube_Channel_Pagination].

== Setting ==

Advanced Youtube Channel Pagination Setting:-We have given from backend admin must set all setting. 

The website owner have to create below credential for their website.

Demo youtube channel:- UCfPLDrpFPVEJBFm0woqur2A
Demo youtube API Key:- AIzaSyBKANNBOEWuI41YQKRi7f6g3M7WhecXYtk;
Default per page:- 04;
Note: Pleas do not use above credential on production this is only for test purpose.